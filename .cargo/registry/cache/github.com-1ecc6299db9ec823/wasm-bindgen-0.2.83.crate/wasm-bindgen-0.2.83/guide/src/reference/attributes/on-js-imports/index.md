# `#[wasm_bindgen]` on JavaScript Imports

This section enumerates the attributes available for customizing bindings for
JavaScript functions and classes imported into Rust within an `extern "C" { ... }`
block.
